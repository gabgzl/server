#!/bin/bash

#variables
hora=$(date "+%H:%M:%S")
fecha=$(date "+%Y%m%d")
directorio_origen="$1"
directorio_destino="$2"

#Funcion para registrar eventos en el log
log() {
	echo "$fecha - $hora - $1|$2" >> /var/log/backup.log
}

#Funcion para enviar por correo el log
enviar_log() {
	mutt -s "Log de respaldo" root < /var/log/backup.log
}

#Funcion para realizar respaldo
hacer_backup() {
	#verifica si existe el directorio
	if [ ! -d "$directorio_origen" ]; then
		log "Directorio $directorio_origen no encontrado" "Error"
		return
	fi
	nombre_backup="${directorio_origen}_bkp_$fecha.tar.gz"
	tar -czf "$directorio_destino/$nombre_backup" -C "$directorio_origen" .
	log "Respaldo de $directorio_origen" "Exito"
}

#Opcion de ayuda
while getopts "h" opcion; do
	case $opcion in
		h)
			echo "Uso: $0 directorio_origen directorio_destino"
			exit
			;;
		\?)
			echo "Opcion no valida: -$OPTARG"
			exit 1
			;;
	esac
done

#Si no ingresa argumentos
if [ "$#" -ne 2 ]; then
	echo "Uso: $0 directorio_origen directorio_destino"
	exit 1
fi

#Realizar respaldo
hacer_backup "$directorio_origen" "$directorio_destino"

#Enviar el log por correo
enviar_log
